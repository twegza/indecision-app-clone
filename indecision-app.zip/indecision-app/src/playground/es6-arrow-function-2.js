const user = {
    name: 'Ahmed Hamdy',
    cities: ['Sohag', 'Cairo', 'NY'],
    printWhereIlived: function(){
        const cityMessage = this.cities.map((city) => {
            return this.name + ' has lived in ' +city + ' before!'; 
        });  
        return cityMessage;
        //That hena shawret 3al name ely fo2 w gabeto hena
        //const that = this;
        //law shelna el 'that' de w khalinaha arrow function hateshta3'al mn 3'er errors
        //Hena ba2a for each gabet kol city name w 7ateto 
        this.cities.forEach((city) => {
            console.log(this.name + ' has lived in ' + city);
        });
    }
};
console.log(user.printWhereIlived());

const bayern = {
    captainsDates: ['2013','2020'],
    captains: ['Lahm','Neuer'],
    giveMeDetailsAboutBayern(){
            return this.captains.map(() => this.captains + ' is the captain then! ');
        }
};
console.log(bayern.giveMeDetailsAboutBayern());

