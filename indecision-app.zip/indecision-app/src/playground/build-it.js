const phrase = "Some text is shown here!"

var appRoot = document.getElementById('app');

const hideAndSeekClick = () => {

};

const hideAndSeek = () => {
    const template = (
        <div>
            <h1> Hide and Seek Game! </h1>
            <button onClick={hideAndSeekClick}>Show Details!</button>
            <h3>{phrase}</h3>
        </div>
    );
    ReactDOM.render(template, appRoot);
}
hideAndSeek();