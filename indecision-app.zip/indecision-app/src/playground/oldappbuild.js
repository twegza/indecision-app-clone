console.log('the app is running');

//JSX - JavaScript XML
//createElement content: 1. Tag, 2. Key Value Name (ID, Class), and 3. HTML tag content.
//var firstemplate = React.createElement("p", null, "This the first paragraph template variable!");

const app = {
    title: 'Indecision App',
    subtitle: 'Let me help you decide!',
    options: []
};
const onFormSubmit = (a) => {
    a.preventDefault();
    const option = a.target.elements.option.value;
    if(option){
        app.options.push(option);
        a.target.elements.option.value = '';
        renderPlease();
    }
    console.log('Item Added!');
};
const onRemoveAll = () => {
    app.options = [];
    renderPlease();
    console.log('All Removed!');
};
const onMakeDecision = () => {
    const randomNum = Math.floor(Math.random() * app.options.length);
    const option = app.options[randomNum];
    alert(option);
};
var appRoot = document.getElementById('app');
//const numbers = [1,2,3];
const counter = 0;
const renderPlease = () => {
    const template = (
        <div>
            <title>Indecision App!</title>
            <h1>{app.title}</h1>
            {app.subtitle && <p>{app.subtitle}</p>}
            <p>{app.options.length > 0 ? 'Here are your options':'No options!'}</p>
            <button disabled={app.options.length==0} onClick={onMakeDecision}>What Should I do please?!</button>
            <button onClick = {onRemoveAll}>Remove All!</button>
            {
                // numbers.map((number) => {
                //     return <p key={number}>Number: {number}</p>;
                // })
            }
            <ol>
                {
                    app.options.map((option) => <li key={option}>{option}</li>)
                }
            </ol>
            <form onSubmit={onFormSubmit}>
                <input type = "text" name = "option"/>
                <button>Add Option!</button>
            </form>
        </div>
    );
    ReactDOM.render(template, appRoot);
};
renderPlease();  