class Person {
    constructor (name = 'Ahmed Hamdy', age = 0){
        this.name = name  || 'No Name';
        this.age = age || 'No Age';
    }
    getGreeting (){
        return `Hi I'm test | My Name is ${this.name} and my age is ${this.age} year(s) old`;
    }
}

class Student extends Person {
    constructor (name, age, major)
    {
        super(name, age);
        this.major = major;
    }
    hasMajor() {
        return !!this.major;
    }
    getGreeting(){
        let description = super.getGreeting();
        if (this.hasMajor()){
            description += ` My Major is ${this.major}`
        }
        return description;
    }
}


const me = new Student ('Ali Hassan', '23', 'CS');
console.log(me.getGreeting());