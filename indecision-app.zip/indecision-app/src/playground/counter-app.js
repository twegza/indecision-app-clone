let count = 0; //Counter Variable
//Function for the add logic
const addOne = () => {
    count++;
    renderCountApp();
};
//Function for the minus logic
const MinusOne = () => {
    count--;
    renderCountApp();
};
//Function to reset the counter
const toZeroAgain = () => {
    count = 0;
    renderCountApp();
};

//Separate rendering function!
const renderCountApp = () => {
    const counterTemplate = (
        <div>
            <title>Counter Mini Project!</title>
            <h1>We are Counting: {count} </h1>
            <button id="my-id" className="our-class" onClick = {addOne}>+1</button>
            <button id="my-id" className="our-class" onClick = {MinusOne}>-1</button>
            <button id="my-id" className="our-class" onClick = {toZeroAgain}>Reset</button>
        </div>
    );
    //THIS APP RENDER LINE!
    ReactDOM.render(
        counterTemplate, appRoot  );
};
renderCountApp();