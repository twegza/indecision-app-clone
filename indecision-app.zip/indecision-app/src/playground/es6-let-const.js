var nameVar = 'Ahmed';
var nameVar = 'Hassan Hindawy';
console.log('nameVar', nameVar);

let nameLet = 'Ali Alokka';
nameLet = 'Honda w kda';

console.log('nameLet', nameLet);