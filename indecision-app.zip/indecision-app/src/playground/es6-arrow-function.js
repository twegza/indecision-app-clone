const firstName = (name) => {
    return name.split(' ')[0];
}
console.log(firstName("Ahmed Hamdy"));

const getFirstName = (name) => name.split(' ')[0];
console.log(getFirstName('Ahmed Hamdy'));