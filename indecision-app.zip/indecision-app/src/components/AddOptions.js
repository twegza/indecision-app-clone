import React from 'react';


export default class AddOptions extends React.Component {
    state = {
        error: undefined
    }
    constructor (props) {
        super(props);
        this.AddOption = this.AddOption.bind(this);
        this.state = {
            errorMsg: undefined
        };
    }
    AddOption(event){
        event.preventDefault();
        //the trim here because if we need the if condition to detect an empty input
        const option = event.target.elements.option.value.trim();
        event.target.elements.option.value = '';
        const errorMsg = this.props.AddOption(option);


        this.setState(() => ({ errorMsg: errorMsg }));
    }
    render() {
        return (
            <div>
                {this.state.errorMsg && <p className="add-option-error">{this.state.errorMsg}</p>}
                <form className="add-option" onSubmit={this.AddOption}>
                    <input className="add-option__input" type = "text" name = "option"/>
                    <button className="button">Add Option</button>
                </form>
            </div>
           );
    }
}