import React from 'react';
import AddOptions from './AddOptions';
import Header from './Header';
import Action from './Action';
import Options from './Options';
import OptionModal from './OptionModal';

export default class IndecisionApp extends React.Component {
    constructor(props){
        super(props);
        this.DeleteOptions = this.DeleteOptions.bind(this);
        this.handlePickArandom = this.handlePickArandom.bind(this);
        this.AddOption = this.AddOption.bind(this);
        this.DeleteOneOption = this.DeleteOneOption.bind(this);
        this.state = {
            options: props.options,
            selectedOption: undefined
        };
    }
    //a function to update the array with the new added options
    componentDidUpdate(prevProps, prevState) {
        if (prevState.options.length !== this.state.options.length) {
          const json = JSON.stringify(this.state.options);
          localStorage.setItem('options', json);
        }
    }
    // a fuction to call and retrieve what we added to the array to make sure that everything working well
    componentDidMount(){
        //this try catch is here to make sure that there is no any unvalid inputs
        try {
          const json = localStorage.getItem('options');
          const options = JSON.parse(json);
    
          if (options) {
            this.setState(() => ({ options }));
          }
        } catch (e) {
          // Do nothing at all
        }
    }
    componentWillUnmount(){
        console.log('Unmount ');
    }
    //Add Option to the array and the screen function
    AddOption(option){
            if(!option) {
                return 'Please enter a value!';
            }
            else if(this.state.options.indexOf(option) > -1){
                return 'This option already exist'
            }
            this.setState((prevState) => ({ options: prevState.options.concat([option])}));
    }
    //Handling the picking
    handlePickArandom(){
        const randomNum = Math.floor(Math.random() * this.state.options.length);
        const option = this.state.options[randomNum];
        this.setState((selectedOption)=>({
            selectedOption: option
        }));
    }
    //Handle Delete Options Function
    DeleteOptions(){
        this.setState(() => ({ options: [] }));
    }
    DeleteOneOption(optionToRemove){
        this.setState((prevState) => ({
            options: prevState.options.filter((option) => optionToRemove !== option)
        }));
    }
    //the render function
    render(){
        //Component props
        const title = 'Indecision Dashboard';
        const subtitle = 'Put your life in the hand of a computer!';
        // const options = ['First Thing', 'Second Thing', 'Third Thing']; 
        return (
            <div>
                <Header title={title} subtitle={subtitle}/>
                <div className="container">
                    <Action 
                        hasOptions={this.state.options.length > 0}
                        handlePickArandom={this.handlePickArandom}
                    />
                    <div className="widget">
                        <Options
                            options={this.state.options}
                            DeleteOptions = {this.DeleteOptions}
                            DeleteOneOption = {this.DeleteOneOption}
                        />
                        <AddOptions
                            AddOption = {this.AddOption}
                        />
                    </div>
                </div>
                <OptionModal 
                    selectedOption = {this.state.selectedOption}
                />
            </div>
        );
    }
}
//
IndecisionApp.defaultProps = {
    options: []
};